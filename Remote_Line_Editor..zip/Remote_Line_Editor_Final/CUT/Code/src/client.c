#include "../include/client.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h> //For Sockets
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#define DATA_DIR "../data/"
#define USERS "../data/users.txt"
#define PORT 8021

/* This Global variable is used for signal handler function */
int sockid;

/* Function to handle ctrl+c */
void signalHandler(int signum) {
    if (signum == SIGINT) {
        // send bye to server
        send(sockid, "bye", 3, 0);
        exit(0);
    }
}

int main() {
    while (1) {
        c client;
        CreateSocket(&client);
        sockid = client.socketfd;

        /* register the signal handler for ctrl+c */
        signal(SIGINT, signalHandler);

        /* connect to server */
        ConnectToServer(&client);

        /* receive connection confirmation from server */
        ReceiveDataFromServer(&client);

        /* get username and password from user */
        char username[100] = "", password[100] = "";
        printf("\nEnter the username: ");
        fgets(username, 100, stdin);
        username[strlen(username) - 1] = '\0';

        
        printf("Enter the password: ");
        fgets(password, 100, stdin);	
	printf("--------------------\n");
        password[strlen(password) - 1] = '\0';
        
        int u = strcmp(username, "");
        int p = strcmp(password, "");
        if (u == 0 && p == 0) {
            strcpy(username, "anonymous");
            strcpy(password, "password");
        }
        /* authenticate user */
        if (AuthenticateUser(username, password, &client)) {
            if (strcmp(username, "anonymous") != 0)
                printf("Authenticated User\n");
            else {
                printf("Anonymous Entry\n");
            }
            while (1) {
                /* get user input */
                char input[100] = "";
                printf("Enter the command you want to execute: ");
                fgets(input, 100, stdin);
                input[strlen(input) - 1] = '\0';
                if (feof(stdin)) {
                    DisconnectClient(&client);
                    exit(0);
                }

                char *token = strtok(input, " ");
                int arguments = -1;
                char command[100] = "";
                while (token != NULL) {
                    strcat(command, token);
                    strcat(command, " ");
                    arguments++;
                    token = strtok(NULL, " ");
                }
                /* remove trailing space */
                command[strlen(command) - 1] = '\0';
                char com[100] = "";
                strcpy(com, command);

                /* separate command and arguments */
                char *subcommand = strtok(command, " ");

                if (strcmp(subcommand, "ls") == 0 || strcmp(subcommand, "pwd") == 0 && arguments == 0) {
                    SendDataToServer(command, &client);
		}
	    	else if (strcmp(subcommand, "print") == 0 && arguments <= 2) {
                	if (arguments == 0) {
                        	SendDataToServer(command, &client);
                    	}else if (arguments == 1) {
                        /* check argument is a number */
                        	char *subarg1 = strtok(NULL, " ");
                        	int number = atoi(subarg1);
                        	if (number <= 0) {
                        	    	printf("Value must be a number and should be greater than 0\n");
                            		continue;
                        	}
                        /* send command to server */
                        	SendDataToServer(com, &client);
                    	}else {
                        /* check both arguments are numbers */
                        	char *subarg = strtok(NULL, " ");
                        	int number1 = atoi(subarg);
                        	subarg = strtok(NULL, " ");
                        	int number2 = atoi(subarg);
                        	if (number1 <= 0 || number2 <= 0) {
                            		printf("Value must be a number and should be greater than 0\n");
                            		continue;
                        	}
                        	/* send command to server */
                        	SendDataToServer(com, &client);
                    	}
                }else if (strcmp(subcommand, "edit") == 0 && arguments == 1) {
                    /* check whether the argument is a number */
                  	char *subarg = strtok(NULL, " ");
                    	int number = atoi(subarg);
                    	if (number <= 0) {
                        	printf("Value must be a number and should be greater than 0\n");
                        	continue;
                    	}
                    	SendDataToServer(com, &client);
                	} else if (strcmp(subcommand, "select") == 0 && arguments == 1) {
                    		SendDataToServer(com, &client);
                	} else if (strcmp(subcommand, "bye") == 0 && arguments == 0) {
                    		DisconnectClient(&client);
                    		break;
                	} else if (strcmp(subcommand, "clear") == 0 || strcmp(subcommand, "c") == 0) {
                    	system("clear");
                   	continue;
                	} 
	    	else {
                	if (strcmp(subcommand, "ls") == 0 && arguments > 0) {
                        	printf("ls : many arguments, try with few arguments\n");
                      	 	}
			else if (strcmp(subcommand, "print") == 0 && (arguments > 2)) {
                        	printf("print : many arguments. try with few arguments\n");
                    	} else if (strcmp(subcommand, "edit") == 0 && (arguments > 1 || arguments < 1)) {
                        	if (arguments > 1) {
                            		printf("edit : too many arguments,give only one number\n");
                        	} else {
                            		printf("<LINENUM> is missing in command : edit <LINENUM>\n");
                        	}
                    	} else if (strcmp(subcommand, "select") == 0 && (arguments > 1 || arguments < 1)) {
                        	if (arguments > 1) {
                            		printf("select : many arguments, try with few arguments\n");
                        	} else {
                            		printf("<FILENAME> is missing in command : select <FILENAME>");
                        	}
                    	} else if (strcmp(subcommand, "bye") == 0 && arguments >= 1) {
                        	printf("bye : many arguments, try with few arguments\n");
                    	} else {
                        	printf("Invalid command\n");
                    	}
                    	continue;
                }

                /* receive data from server */
                if (strcmp(subcommand, "edit") == 0) {
                    EditLine(&client);
                } else if (strcmp(subcommand, "print") == 0) {
                    ReceiveFile(&client);
                } else {
                    ReceiveDataFromServer(&client);
                }
            }
        } else {
            printf("AUTHENTICATION_FAILED\n");
            DisconnectClient(&client);
        }

        return 0;
    }
}
