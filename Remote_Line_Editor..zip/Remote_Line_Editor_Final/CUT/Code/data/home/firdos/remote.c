#include<stdlib.h>
int main(int argc, char const *argv[]) {
    red
    return 1;
}
