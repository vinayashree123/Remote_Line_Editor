#include <stdio.h>
int main(int argc, char const *argv[]) {
    //start
    return 1;
}
