#include<string.h>
#include<stdlib.h>
Raksha
hi
bye
