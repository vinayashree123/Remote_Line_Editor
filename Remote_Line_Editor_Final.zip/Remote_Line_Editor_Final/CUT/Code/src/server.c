#include "../include/server.h"	//user defined header file
#include "../include/user.h"	//user defined header file
#include <netinet/in.h>		
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h> //For Sockets
#include <unistd.h>     //for fork

/* TCP server program*/

int main() {
	// create server object
    	ser server;
    	createServer(&server);
    	LoadUsersData(&server);
    	while (1) {
        	// accept connection from client and store the socket descriptor
        	int clientfd = AcceptConnections(&server);
        	printf("Client is now Connected\n");
        	SendDataToClient(clientfd, "welcome, Connected to server and ready to use");
		printf("------------------------");
        	char data[100] = "";
        	strcpy(data, ReceiveDataFromClient(clientfd, &server));
        	char command[100] = "", name[100] = "", password[100] = "", dir[100] = "", filename[100] = "";
        	char *token = strtok(data, " ");
        	strcpy(command, token);
        	token = strtok(NULL, " ");
        	strcpy(name, token);
        	token = strtok(NULL, " ");
        	strcpy(password, token);

        	user current_user;
        	User(name, password, &current_user);

        	if (AuthenticateUser(clientfd, &current_user, &server)) {
            		while (1) {
                		strcpy(data, "");
                		strcpy(dir, current_user.dir);
                		strcpy(data, ReceiveDataFromClient(clientfd, &server));
                		token = strtok(data, " ");
                		strcpy(command, token);

                		if (strcmp(command, "ls") == 0) {
                    			ListDirContents(clientfd, dir);
                		}else if (strcmp(command, "pwd") == 0) {
                    			SendDataToClient(clientfd, dir);
                		}else if (strcmp(command, "edit") == 0) {
                    			int line_number;
                    			token = strtok(NULL, " ");
                    			line_number = atoi(token);
                    			if (strcmp(filename, "") == 0)
                        			SendDataToClient(clientfd, "0");
                    			else
                        			EditLine(clientfd, filename, line_number, &server);
                		}else if (strcmp(command, "print") == 0) {
                    			if (strcmp(filename, "") == 0)
                        			SendDataToClient(clientfd, "0");
                    			else {
                        			int start_line = 1, end_line = -1;
                        			token = strtok(NULL, " ");
                        			if (token != NULL) {
                            				start_line = atoi(token);
                        			}
                        			token = strtok(NULL, " ");
                        			if (token != NULL) {
                            				end_line = atoi(token);
                        			}
                        			ViewFile(clientfd, filename, start_line, end_line, &server);
                    			}
                		}else if (strcmp(command, "select") == 0) {
                    			token = strtok(NULL, " ");
                    			strcpy(filename, token);
                    			if (strcmp(filename, "") != 0)
                        			SelectFile(filename, dir, clientfd);
                			}else if (strcmp(command, "bye") == 0) {
                    				close(clientfd);
                    				break;
                			}else {
                    				SendDataToClient(clientfd, "Invalid command");
                			}
            			}
        		}
    		}
    	return 0;
}
